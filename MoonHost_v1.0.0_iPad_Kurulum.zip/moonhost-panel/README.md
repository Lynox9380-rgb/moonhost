# MoonHost Panel v1.0.0

Mobil uyumlu statik arayüz prototipi.

## GitHub Pages ile yayınlama
1. Bu klasördeki dosyaları GitHub deposunun kök dizinine yükleyin.
2. Repository Settings > Pages bölümünü açın.
3. Deploy from a branch seçin.
4. Branch: `main`, Folder: `/ (root)` seçip kaydedin.

## Önemli
Bu sürüm yalnızca arayüz prototipidir. Sunucu kayıtları tarayıcı localStorage alanında demo amaçlı tutulur. Gerçek BDS, API, kimlik doğrulama, Docker, konsol ve dosya yönetimi içermez.
