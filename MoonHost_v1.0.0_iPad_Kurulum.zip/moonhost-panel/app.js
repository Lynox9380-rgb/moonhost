"use strict";
const STORAGE_KEY = "moonhost_demo_servers_v1";
const pages = {dashboard:"Genel Bakış",servers:"Sunucularım",create:"Sunucu Oluştur",console:"Konsol",files:"Dosya Yöneticisi",players:"Oyuncular",backups:"Yedeklemeler",settings:"Ayarlar"};
const $ = s => document.querySelector(s);
const sidebar = $("#sidebar"), toast = $("#toast");
let servers = loadServers(), toastTimer;
function loadServers(){try{const x=JSON.parse(localStorage.getItem(STORAGE_KEY)||"[]");return Array.isArray(x)?x:[]}catch{return []}}
function saveServers(){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(servers))}catch{showToast("Tarayıcı depolamasına kayıt yapılamadı.")}}
function showToast(message){toast.textContent=message;toast.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove("show"),3500)}
function navigate(page){if(!pages[page])return;document.querySelectorAll(".page").forEach(e=>e.classList.toggle("active",e.id===page));document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));$("#pageName").textContent=pages[page];sidebar.classList.remove("open");if(page==="servers"||page==="dashboard")renderServers();window.scrollTo({top:0,behavior:"smooth"})}
document.querySelectorAll("[data-page]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.page)));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.go)));
$("#menuBtn").addEventListener("click",()=>sidebar.classList.toggle("open"));
$("#newServerBtn").addEventListener("click",()=>navigate("create"));
function escapeHTML(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function renderServers(){
 $("#totalServers").textContent=servers.length;
 const html=servers.length?servers.map(s=>`<article class="server-card"><div class="server-info"><div class="server-icon">▣</div><div><h3>${escapeHTML(s.name)}</h3><p>${escapeHTML(s.version)} · ${s.ram} GB RAM hedefi</p><p class="demo-label">● Demo kaydı — gerçek sunucu değil</p></div></div><div class="server-actions"><button disabled>Başlat</button><button disabled>Durdur</button><button class="delete-btn" data-delete="${escapeHTML(s.id)}">Sil</button></div></article>`).join(""):`<div class="empty-state"><div>▣</div><h3>Henüz sunucu oluşturulmadı</h3><p>İlk demo sunucu kaydını oluşturmak için Sunucu Oluştur bölümünü kullan.</p></div>`;
 $("#serverList").innerHTML=html;$("#allServers").innerHTML=html;
 document.querySelectorAll("[data-delete]").forEach(b=>b.addEventListener("click",()=>{if(!confirm("Bu demo kaydını silmek istiyor musun?"))return;servers=servers.filter(s=>s.id!==b.dataset.delete);saveServers();renderServers();showToast("Demo kaydı silindi.")}));
}
$("#serverForm").addEventListener("submit",e=>{e.preventDefault();const name=$("#serverName").value.trim(),version=$("#serverVersion").value,ram=Number($("#serverRam").value);if(!name||!Number.isInteger(ram)){showToast("Geçerli bilgileri gir.");return}servers.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),name,version,ram});saveServers();$("#serverForm").reset();renderServers();showToast("Demo kaydı oluşturuldu. Minecraft sunucusu kurulmadı.");navigate("servers")});
$("#commandForm").addEventListener("submit",e=>{e.preventDefault();const input=$("#commandInput"),command=input.value.trim();if(!command)return;const output=$("#terminalOutput");const line=document.createElement("p");line.textContent="> "+command;output.appendChild(line);const warning=document.createElement("p");warning.className="terminal-yellow";warning.textContent="Komut gönderilmedi: Gerçek Minecraft backend bağlantısı yok.";output.appendChild(warning);output.scrollTop=output.scrollHeight;input.value=""});
renderServers();